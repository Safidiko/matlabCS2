%% Lab 1:
imgOrg = double(imread('.\images\Lena.png'));                                                                                       
[ligne,colonne] = size(imgOrg); 
TS = 25;                                                                                                                         
delta = 0;                                                                                                                        

%% Ciphering parameters:
binPath     = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
cipherClass = 'main_pkg.Main';
cipherModes = {'AES','PQAES_SHA','PQAES_SHA3','PQAES_KECCAK','PQAES_SHAKE'};
cipherMode  = cipherModes{2};
repertoire_courant    = pwd;
input_java = appendToPath(repertoire_courant,'input_java');
output_java   = appendToPath(repertoire_courant,'output_java');

%% 2- GET THE INITIAL PARAMETERS:
% S = [x0';y0';r;z0']
S = abs(rand(4,1));

% Compressive ratio:
compressive_ratio = 4/16;
ligne_cr          = round(compressive_ratio * ligne);
% Sampling distance:
sampling_distance = 20;
% 256 Bits = 32 blocks of 8 bits:
P = generateBitBlocks(32,8);

%% GENERATION DES PARAMETRES Q:
Q   = initialParameters(P,S);
% Inutile --> Pour le zigzag:
x_0 = delimit(Q(1,:),colonne,1);
y_0 = delimit(Q(2,:),ligne,1) ;

g_0   = Q(3,:);
r_max = .6;
r_min =.3;
r     = Q(4,:);

%% GENERATION DE LA MATRICE SENSING
sensing_matrix = sensingMatrix(ligne_cr,colonne,[sampling_distance;g_0;r]);

%% SPARSIFICATION EN UTILISANT LA TRANSFORMEE D'ONDELETTE
Psi = dwtmtx(colonne,'db2',3);                                                                                                        % 用于稀疏化
imgSp = Psi * imgOrg * Psi';


%% TRESHOLDING
imgSp(abs(imgSp) <= TS) = 0; 

imgZigzag =zigzag(imgSp,x_0,y_0);
z1 = Lorenz_chaotic(0,2*ligne*colonne);
z1_test = z1;
%% SCRAMBILG USING ARNOLD SCRAMBLING:
imgSpcon = enscramble_arnold(imgZigzag,z1);
z1_test_2 = z1;
%% COMPRESSIVE SENSING:
imgCS = sensing_matrix * imgSpcon;

%% QUANTIFICATION
max_im = max(max(imgCS));
min_im = min(min(imgCS));
img_en = round(255*(imgCS-min_im)/(max_im-min_im));

% TRANSFORM THE IMAGE TO BYTE
image = img_en - 128;

%% ECRITURE DANS INPUT JAVA DE LA MATRICE QUANITFIE:
input_image_name = 'image.csv';
parent           = cd(input_java);
writematrix(image,input_image_name);
cd(parent);

chemin_image_quantifie            = appendToPath(input_java,input_image_name);
%% Pour windows uniquement: 
chemin_image_quantifie_java       = normalizePathForJava(chemin_image_quantifie);
chemin_image_chiffree_java        = normalizePathForJava(output_java);
%% PARTIE JAVA:
% javaCipheringLauncher(binPath,className,cipherType,input_path,output_path,ligne,colonne)
javaCipheringLauncher(binPath,cipherClass,cipherMode,chemin_image_quantifie_java,chemin_image_chiffree_java,ligne_cr,colonne);

%% READ CIPHERED IMAGE OUTPUT BY JAVA: 
chemin_image_chiffree = appendToPath(output_java,'imageCiphered');
parent = cd(chemin_image_chiffree);
image = readmatrix('imageCiphered.csv');
cd(parent);

%% UTILISATION DE LA STEGANOGRAPHIE/ INSERTION:
%{
    choix de l'image porteuse:
    - nombres de lignes   : 4 x ligne_cr
    - nombres de colonnes : même que celui de l'image compressé 
%}

image_hote  = imread('.\images\Baboon.bmp');
image_stego = stega(image_hote,image);

imageComparator(image_hote,image_stego);
%% ECRIRE L'IMAGE A DECHIFFRER DANS IMAGE A DECHIFFRER:
chemin_image_a_dechiffrer = appendToPath(repertoire_courant,'imageToDecipher');
parent =cd(chemin_image_a_dechiffrer);
writematrix(image,'imageToDecipher.csv');
cd(parent)
chemin_image_a_dechiffrer_java = appendToPath(chemin_image_a_dechiffrer,'imageToDecipher.csv');

%% 2EME ETAPE JAVA
binPath        = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
decipherClass  = 'main_pkg.DeCipher';
cipheringType  = cipherMode;
%% POUR WINDOWS UNIQUEMENT
parametersPath                 = normalizePathForJava(output_java);
chemin_image_a_dechiffrer_java = normalizePathForJava(chemin_image_a_dechiffrer_java);
%% DECHIFFREMENT JAVA:
javaDecipheringLauncher(binPath,decipherClass,cipheringType,parametersPath,chemin_image_a_dechiffrer_java,ligne_cr,colonne);

%% READ FINAL OUTPUT:
chemin_final_output = appendToPath(output_java,'finalOutput');
parent = cd(chemin_final_output);
image = readmatrix('finalOutput.csv');
cd(parent);

%% Inverse de la quantification + 128
image = image + 128; 

%% DECHIFFREMENT
imgEnc = double(image);                                                                                         
imgIqua = imgEnc * (max_im-min_im)/255 + min_im;

% imgIre = OMP_2D(imgIqua,sensing_matrix,ligne,colonne);
imgIre = zeros(ligne,colonne);
for i = 1 : colonne                                                                                                                   % 列循环 
    imgIre(:,i) = OMP(imgIqua(:,i),sensing_matrix,round(ligne_cr/4));                                                                               % OMP重构算法
end
%z2 = Lorenz_chaotic(0,2*ligne*colonne);
imgIcon = descramble_arnold(imgIre,z1);
imgIcon = izigzag(imgIcon,x_0,y_0);
imgIsp = Psi' * imgIcon * Psi;
img_de = uint8(imgIsp);

imageComparator(imgOrg,img_de);