clc 
close all
clear all
 
imgOrg = double(imread('.\images\Lena.png'));                                                                                     % ���ļ�  
[row,col] = size(imgOrg);
TS = 25;
r = 4/16;                                                                                                                         % ѹ����
delta = 0;                                                                                                                        % ƫ����
M = round(row*r);                                                                                                                 % ����ֵȡ����

%% ���ܹ���
a = 2.987; cx0 = 0.678; cy0 = 0.496;                                                                                              % ��άèӳ��ĳ�ʼֵ
d = 25;                                                                                                                           % ��������
catSeq = NewMap((d+1)*M*col,a,cx0,cy0);
catDeqcon = zeros(1,M*col);
for i = 1 : M*col
    catDeqcon(i) = 1 - 2*catSeq(100 + d*i);
end
Phi = reshape(catDeqcon,M,col) * sqrt(2/M);                                                                                       % ������������ 
z1 = Lorenz_chaotic(0,2*row*col);                                                                                                 % ��������
Psi = dwtmtx(col,'db2',3);                                                                                                        % ����ϡ�軯
imgSp = Psi * imgOrg * Psi';
imgSp(abs(imgSp) <= TS) = 0;
% ϡ�軯
imgSpcon = enscramble_arnold(imgSp,z1);                                                                                           % ϵ������Arnold����
imgMea = Phi * imgSpcon;                                                                                                          % ����
mmax = max(imgMea(:)); mmin = min(imgMea(:));
img_en = round(255*(imgMea-mmin)/(mmax-mmin));                                                                                    % ����
img_en = uint8(img_en);

%% ���ܹ���
imgEnc = double(img_en);                                                                                         
imgIqua = imgEnc * (mmax-mmin)/255 + mmin;

imgIre = zeros(row,col);
for i = 1 : col                                                                                                                   % ��ѭ�� 
    imgIre(:,i) = OMP(imgIqua(:,i),Phi,round(M/4));                                                                               % OMP�ع��㷨
end
imgIcon = descramble_arnold(imgIre,z1);                                                                                           % �������㷨
imgIsp = Psi' * imgIcon * Psi;
img_de = uint8(imgIsp);

%% ��β����
figure(2);
subplot(1,3,1); imshow(uint8(imgOrg)); title(''); 
subplot(1,3,2); imshow(uint8(img_en)); title('ѹ��ͼ��');
subplot(1,3,3); imshow(uint8(img_de)); title('�ؽ�ͼ��'); 
[ssim,psnr] = PS(uint8(img_de),uint8(imgOrg));                                                                                    % ��������
fprintf('SSIM :\n  ');                                                                                                              
disp(ssim);
fprintf('PSNR :\n  ');                                                                                                           
disp(psnr);