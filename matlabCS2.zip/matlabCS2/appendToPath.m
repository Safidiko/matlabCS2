function fullPath = appendToPath(parent,child)
    fullPath = fullfile(parent,child);
end