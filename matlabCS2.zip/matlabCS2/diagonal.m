function [v1,v2] = diagonal(image)
%% creatrion d'un vecteurs des pixels en diagonale
    [max_row,max_col,~] = size(image);
    matrice = rgb2gray(image);
    if(max_row ~= max_col)
            minDim = min(max_row,max_col);
            max_row = minDim;
            max_col = minDim;
    end
    
    v1 = zeros(max_row * max_col,1);
    pos = 1;
    for ii = 1:(max_row + max_row-1)

        if ii <= max_row
            row_start = ii;
            col_start = 1;
        else
            col_start = ii - max_col + 1;
            row_start = max_col;
        end 
        row = row_start;
        col = col_start;

        while(row >= 1 && col <= max_col)
            v1(pos,1) = matrice(row,col);
            row = row-1;
            col = col+1;
            pos = pos +1;
        end 
    end
     v2 = [v1(2:end);v1(1)];
end