function secretImage = extract_image(stegoImage, secretImageSize, outputImagePath)
    
    
    % Flatten the stego image into a single row of bits
    stegoBits = de2bi(stegoImage(:), 8, 'left-msb');
    
    % Extract the LSB of the stego image
    secretBits = stegoBits(:, end);
    
    % Reshape the bits back to the original secret image size
    secretBits = reshape(secretBits, [], 8);
    secretImage = reshape(bi2de(secretBits, 'left-msb'), secretImageSize);
    
    % Save the extracted secret image
    imwrite(secretImage, outputImagePath);
end