function P = generateBitBlocks(BLOCKS,BITS)
%% STEP 1: GENERATE THE 32 BLOCKS OF 8 BITS
P = randi([0,1],BLOCKS,BITS);
end
