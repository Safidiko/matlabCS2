function javaDecipheringLauncher(binPath,decipherClass,cipheringType,parametersPath,imToDecipherPath,ligne,colonne)
%% PARAMETERS TO CHANGE: 
% binPath = 'D:\ECLIPSE_PROJECT\Article4_QuantumCipherMode2\bin';
% decipherClass = 'main_pkg.DeCipher';
% cipheringType = 'PQAES_SHAKE';
% imToDecipherPath = '"C:\\Users\\Sitraka\\Documents\\MATLAB\\Simulaka mila vitaina\\output_java"';
% ligne = 192;
% colonne = 256;

command = sprintf('java -cp %s %s %s %s %s %d %d',binPath, decipherClass,cipheringType,parametersPath,imToDecipherPath,ligne,colonne);
[r,s] = system(command);
disp(s)