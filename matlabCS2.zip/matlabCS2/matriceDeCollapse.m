function matrice = matriceDeCollapse(collapse,d)
    [ligne,c] =size(collapse);
    l = ligne/d;
    l = round(l);
    matrice = zeros(l,c,d);
    for ii = 1:d
        start_idx = (ii - 1)*l+1;
        end_idx   = ii*l; 
         matrice(:,:,ii)= collapse(start_idx:end_idx,:);
    end
end