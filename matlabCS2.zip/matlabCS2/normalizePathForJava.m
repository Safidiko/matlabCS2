function winPath = normalizePathForJava(matlabFilePath)    
    if(ispc)
        matlabFilePath=replace(matlabFilePath,filesep,'\\');
    end
    winPath = sprintf('"%s"',matlabFilePath);
end