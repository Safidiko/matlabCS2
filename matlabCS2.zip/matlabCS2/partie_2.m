% %% 2eme étape de la simulation:
%% Lecture de l'image stéga

%% Obtention de la matrice de mesure

%% reccupération dans JAVA

%% inverse de la quantification:

%% inverse de la compressive sensing:

%% inverse de la DWT 

%% calcul des paramètres 









% %% LECTURE DE LA CSV
image=readmatrix('image_quantifie.csv')+128;
% 
% %% INVERSE DE LA QUANTIFICATION
image = invQuantification(image,max_im,min_im);
% 
%% COMPRESSIVE SENSING INVERSE:
image = decompression(sensing_matrix,image,compressive_ratio);
% imshow(uint8(image))

%% INVERSE DE LA DWT
image = inversedwt(image);

%% AFFICHAGE DE L'IMAGE FINALE}%
subplot(122)
imshow(image);