function imToHide = stegaExtractLSB(imStego,dim,nBits)
%% Paramètres d'entrées:
%% imStego: l'image stégo 
%% dim    : la taille de imToHide [lHide,cHide,dHide]
%% nBits  : nombre de bits à décaper
lHide = dim(1,1);
cHide = dim(1,2);
dHide = dim(1,3);

a = 2 * lHide;

msbLsb =  bitshift(imStego(1:a,1:cHide,1:dHide),nBits);
msb1 = msbLsb(1:lHide,1:cHide,:);
lsb1 = bitshift(msbLsb((1+lHide):end,1:cHide,:),-nBits);
imToHide = bitor(msb1,lsb1);
end