function im_stego = stegaInsertLSB(imHost,imToHide,nBits)
    ratio = round(8/nBits);
    [lHide,cHide,dHide] = size(imToHide);
    [lHost,cHost,dHost] = size(imHost);
    px_own       = lHost*cHost;
    px_necessary = ratio*lHide*cHide;
    if ((dHide>dHost)&&(px_necessary > px_own))
        error("Insertion impossible");
    end
%% Décaper les parties utiles
    im_stego = imHost;
    im_stego(1:2*lHide,1:cHide,:) = bitshift(bitshift(im_stego(1:(2*lHide),1:cHide,:),-nBits),nBits);

%% extraction de tous les msb
    msb = bitshift(imToHide,-nBits);
    lsb = bitshift(bitshift(imToHide,nBits),-nBits);
    msbLsb = cat(1,msb,lsb);
    [a,b,c] = size(msbLsb);
    im_stego(1:a,1:b,1:c) = bitor(im_stego(1:a,1:b,1:c),msbLsb(1:a,1:b,1:c));
end