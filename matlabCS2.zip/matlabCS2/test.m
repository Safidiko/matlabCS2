matTest = rand(10);
maxMin = getExtrema(matTest);
matQ = quantification(matTest,maxMin)
matIQ = invQuantification(matQ,maxMin);
sum(sum(matIQ - matTest))