A = imread("images/Terre.png");
IA=rgb2gray(im2double(A));
c_diag = corrcoef(IA(1:end-1, 1:end-1), IA(2:end, 2:end));
c_vert = corrcoef(IA(1:end-1, :), IA(2:end, :));
c_horz = corrcoef(IA(:, 1:end-1, :), IA(:, 2:end));
figure;
subplot(3,3,1)
plot(IA(1:end-1, 1:end-1), IA(2:end, 2:end),'b'),title(sprintf('Horizontal Orginal image'));
subplot(3,3,2)
plot(IA(1:end-1, :), IA(2:end, :),'b'),title(sprintf('Vertical Orginal image'));
subplot(3,3,3)
plot(IA(:, 1:end-1, :), IA(:, 2:end),'b'),title(sprintf('Diagonal Orginal image'));
IAA=rgb2gray(im2double(A));
c_diage = corrcoef(IAA(1:end-1, 1:end-1), IAA(2:end, 2:end))
c_verte = corrcoef(IAA(1:end-1, :), IAA(2:end, :))
c_horze = corrcoef(IAA(:, 1:end-1, :), IAA(:, 2:end))
subplot(3,3,4)
plot(IAA(1:end-1, 1:end-1), IAA(2:end, 2:end),'r'),title(sprintf('Horizontal chiphered image '));
subplot(3,3,5)
plot(IAA(1:end-1, :), IA(2:end, :),'r'),title(sprintf('Vertical chiphered image'));
subplot(3,3,6)
plot(IAA(:, 1:end-1, :), IA(:, 2:end),'r'),title(sprintf('Diagonal chiphered image'));
