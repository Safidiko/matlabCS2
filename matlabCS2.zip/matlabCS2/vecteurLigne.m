function [v1,v2] = vecteurLigne(image)
    matrice = rgb2gray(image);
    matrice = matrice';
    v1 = matrice(:);
    v2 = [v1(2:end);v1(1)];

end